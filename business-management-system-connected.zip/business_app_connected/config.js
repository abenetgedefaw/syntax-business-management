// Supabase client configuration.
// SAFE: the publishable key is intended for browser/mobile apps when RLS is enabled.
// NEVER put a Supabase secret/service_role key here.
window.SUPABASE_CONFIG = {
  url: 'https://aailuzibnshjabiboeod.supabase.co',
  publishableKey: 'PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE'
};
